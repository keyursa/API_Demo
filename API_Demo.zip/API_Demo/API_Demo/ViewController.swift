//
//  ViewController.swift
//  API_Demo
//
//  Created by Keyur on 03/10/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var tblUSAData: UITableView!

    @IBOutlet weak var btnNext: UIButton!
    private var usaData = [NationData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblUSAData.delegate = self
        tblUSAData.dataSource = self
        btnNext.setTitle("Next", for: .normal)
        self.APIData()
        
    }
    @IBAction func btnNext_Clicked(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

        let secondViewController = storyBoard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.present(secondViewController, animated:true, completion:nil)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return usaData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usaData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "USADataCell", for: indexPath) as! USADataCell
        cell.lblIdNation.text = usaData[indexPath.row].idNation
        cell.lblNation.text = usaData[indexPath.row].nation
        cell.lblIdYear.text = "\(usaData[indexPath.row].idYear ?? 0)"
        cell.lblYear.text = usaData[indexPath.row].year
        cell.lblPopulation.text = "\(usaData[indexPath.row].population ?? 0)"
        cell.lblSlugNation.text = usaData[indexPath.row].slugNation
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You selected cell #\(indexPath.row)!")

    }

    func APIData() {
                
        var request = URLRequest(url: URL(string: "https://datausa.io/api/data?drilldowns=Nation&measures=Population")!)
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            
            if(error == nil){
                
                do {
                    let responseData = try JSONDecoder().decode(ResponseDataModel<NationData?>.self, from: data!)
                    if let val = responseData.data {
                        self.usaData = val
                        print(self.usaData)
                    }
                }
                catch {
                    debugPrint(error.localizedDescription)
                }
            }
            
        }).resume()
            
        }
}

//TableView Cell

class USADataCell: UITableViewCell {
   
    @IBOutlet weak var stackMain: UIStackView!
    
    @IBOutlet weak var lblIdNation: UILabel!
    @IBOutlet weak var lblNation: UILabel!
    @IBOutlet weak var lblIdYear: UILabel!
    @IBOutlet weak var lblYear: UILabel!
    @IBOutlet weak var lblPopulation: UILabel!
    @IBOutlet weak var lblSlugNation: UILabel!
    
    
}

