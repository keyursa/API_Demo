//
//  SecondViewController.swift
//  API_Demo
//
//  Created by Keyur on 09/10/24.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var lblTitleSecond: UILabel!
    
    @IBOutlet weak var tblUSADataSecond: UITableView!

    private var usaData = [NationData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblUSADataSecond.delegate = self
        tblUSADataSecond.dataSource = self
        self.APIData()
        
    }
  
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return usaData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usaData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "USADataCellDetail", for: indexPath) as! USADataCellDetail
        
        let boldAttribute = [
            NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 15.0)!
        ]
        let regularAttribute = [
            NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Light", size: 13.0)!
        ]
        
        let boldIDNation = NSAttributedString(string: "ID Nation", attributes: boldAttribute)
        let regularIDNation = NSAttributedString(string:  "\n" + (usaData[indexPath.row].idNation ?? ""), attributes: regularAttribute)
        
        let boldNation = NSAttributedString(string: "\n\n" + "Nation", attributes: boldAttribute)
        let regularNation = NSAttributedString(string:  "\n" + (usaData[indexPath.row].nation ?? ""), attributes: regularAttribute)
        
        let boldIDYear = NSAttributedString(string: "\n\n" + "ID Year", attributes: boldAttribute)
        let regularIDYear = NSAttributedString(string:  "\n" + "\(usaData[indexPath.row].idYear ?? 0)", attributes: regularAttribute)
        
        let boldYear = NSAttributedString(string: "\n\n" + "Year", attributes: boldAttribute)
        let regularYear = NSAttributedString(string:  "\n" + "\(usaData[indexPath.row].idYear ?? 0)", attributes: regularAttribute)
        
        let boldPopulation = NSAttributedString(string: "\n\n" + "Population", attributes: boldAttribute)
        let regularPopulation = NSAttributedString(string:  "\n" + "\(usaData[indexPath.row].idYear ?? 0)", attributes: regularAttribute)
        
        let boldSlugNation = NSAttributedString(string: "\n\n" + "Slug Nation", attributes: boldAttribute)
        let regularSlugNation = NSAttributedString(string:  "\n" + "\(usaData[indexPath.row].idYear ?? 0)", attributes: regularAttribute)
        
        let newString = NSMutableAttributedString()
        newString.append(boldIDNation)
        newString.append(regularIDNation)
        
        newString.append(boldNation)
        newString.append(regularNation)
        
        newString.append(boldIDYear)
        newString.append(regularIDYear)
        
        newString.append(boldYear)
        newString.append(regularYear)
        
        newString.append(boldPopulation)
        newString.append(regularPopulation)
        
        newString.append(boldSlugNation)
        newString.append(regularSlugNation)
        
        cell.lblDetail.attributedText = newString
        
        return cell
    }

    func APIData() {
                
        var request = URLRequest(url: URL(string: "https://datausa.io/api/data?drilldowns=Nation&measures=Population")!)
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request, completionHandler: { data, response, error -> Void in
            
            if(error == nil){
                
                do {
                    let responseData = try JSONDecoder().decode(ResponseDataModel<NationData?>.self, from: data!)
                    if let val = responseData.data {
                        self.usaData = val
                        print(self.usaData)
                    }
                }
                catch {
                    debugPrint(error.localizedDescription)
                }
            }
            
        }).resume()
            
        }
}

//TableView Cell

class USADataCellDetail: UITableViewCell {
    
    @IBOutlet weak var mainStack: UIStackView!
    @IBOutlet weak var lblDetail: UILabel!
    
}
